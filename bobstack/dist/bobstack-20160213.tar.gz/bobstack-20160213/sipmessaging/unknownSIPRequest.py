from sipRequest import SIPRequest


class UnknownSIPRequest(SIPRequest):
    pass
